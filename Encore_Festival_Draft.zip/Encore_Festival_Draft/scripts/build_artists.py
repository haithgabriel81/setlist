import json
# Spotify lead-artist totals: ChartMasters, September 29, 2026 snapshot.
raw='''Taylor Swift|Pop|Current|94|129951855161
Bad Bunny|Latin|Current|90|117535142370
Drake|Hip-hop|Current|90|104183570415
The Weeknd|R&B|Current|94|89376208915
Ariana Grande|Pop|Current|95|68215411785
Justin Bieber|Pop|Current|88|64298946978
Ed Sheeran|Pop|Current|90|60928665338
Billie Eilish|Pop|Current|92|59299852182
Eminem|Hip-hop|Legend|96|58421755168
Kanye West|Hip-hop|Legend|94|57182839347
BTS|Pop|Current|91|54545386380
Bruno Mars|R&B|Current|97|53299037760
Post Malone|Pop|Current|89|51210351308
Rihanna|R&B|Legend|93|49800495969
Coldplay|Rock|Legend|92|48008408511
Travis Scott|Hip-hop|Current|90|46329763324
Kendrick Lamar|Hip-hop|Current|97|43999971434
Dua Lipa|Pop|Current|89|42465153788
David Guetta|Electronic|Legend|89|40776602154
Lana Del Rey|Pop|Current|92|40320621480
Juice WRLD|Hip-hop|Legend|91|39255821425
Lady Gaga|Pop|Legend|97|38532865500
XXXTENTACION|Hip-hop|Legend|88|36195603168
Future|Hip-hop|Current|89|34550944641
Beyoncé|R&B|Legend|98|32480078200
Olivia Rodrigo|Pop|Current|89|30978228590
Harry Styles|Pop|Current|91|30371412525
SZA|R&B|Current|94|29891530929
Queen|Rock|Legend|98|29884044114
Adele|Pop|Legend|97|29367217772
Doja Cat|Hip-hop|Current|91|28819216465
J. Cole|Hip-hop|Current|93|28374690542
The Beatles|Rock|Legend|98|26796054119
Michael Jackson|Pop|Legend|99|26264559494
Sabrina Carpenter|Pop|Current|89|25369767939
Tyler, The Creator|Hip-hop|Current|95|24945900377
Nicki Minaj|Hip-hop|Current|92|24125915764
Lil Uzi Vert|Hip-hop|Current|88|23772012438
Frank Ocean|R&B|Current|96|21065950992
$uicideboy$|Hip-hop|Current|86|20836633401
Mac Miller|Hip-hop|Legend|93|19800285597
Lil Peep|Hip-hop|Legend|87|19193463369
Elton John|Pop|Legend|97|18835885794
Playboi Carti|Hip-hop|Current|88|16842827550
Nirvana|Rock|Legend|96|16748532532
Daft Punk|Electronic|Legend|96|10618681288
Yeat|Hip-hop|Current|86|9715512405
Charli XCX|Pop|Current|92|11528058795
Calvin Harris|Electronic|Current|90|34311104195
Avicii|Electronic|Legend|94|20841964978
Tiësto|Electronic|Legend|90|16180448620
Marshmello|Electronic|Current|86|23427956294
Kygo|Electronic|Current|88|18762558281
Diplo|Electronic|Current|88|18549296792
Skrillex|Electronic|Current|94|9615465634
Pink Floyd|Rock|Legend|97|13818792668
Metallica|Rock|Legend|95|19118285994
Red Hot Chili Peppers|Rock|Legend|94|22576037182
Arctic Monkeys|Rock|Current|93|28974994987
Green Day|Rock|Legend|92|15952684440
Foo Fighters|Rock|Legend|93|10836717549
Guns N' Roses|Rock|Legend|95|14127387924
Radiohead|Rock|Legend|97|17209824608
Fleetwood Mac|Rock|Legend|96|17250032454
AC/DC|Rock|Legend|92|17517291508
The Rolling Stones|Rock|Legend|96|12849011638
Led Zeppelin|Rock|Legend|98|10160104455
KAROL G|Latin|Current|89|31878264980'''
# Non-stream equivalent album sales = source total EAS minus stream EAS.
# These are estimates across record formats, NOT pure album sales or certifications.
records={'The Beatles':(527384000,30898000),'Michael Jackson':(365367000,39320000),'Taylor Swift':(276272000,160487000),'Queen':(293314000,39797000),'Eminem':(236487000,78471000),'Elton John':(218172000,23602000),'Drake':(204840000,168535000)}
rows=[]
for line in raw.splitlines():
 name,genre,scene,talent,streams=line.split('|');rows.append(dict(id=str(len(rows)),name=name,genre=genre,scene=scene,talent=int(talent),streams=int(streams),records=records[name][0]-records[name][1] if name in records else None,source='https://chartmasters.org/most-streamed-artists-ever-on-spotify/',recordSource='https://chartmasters.org/best-selling-artists-of-all-time/' if name in records else None))
# Editorial discovery-stage roster. Commercial totals are unknown, never fabricated.
for name,talent in [('slayr',87),('Ken Carson',87),('Destroy Lonely',84),('OsamaSon',85),('Nettspend',80),('prettifun',83),('Lucy Bedroque',84),('ezcodylee',83),('2hollis',89),('Fakemink',85),('Bladee',88),('Ecco2k',89)]:
 rows.append(dict(id=str(len(rows)),name=name,genre='Hip-hop' if name!='2hollis' else 'Electronic',scene='Discovery',talent=talent,streams=None,records=None,source='https://soundcloud.com/stories/post/slayr-exclusive-interview-sound-advice' if name=='slayr' else None,recordSource=None))
json.dump({'updated':'2026-09-30','streamDate':'2026-09-29','recordDate':'2026-09-28','artists':rows},open('dist/artists.json','w'),ensure_ascii=False,indent=2)
print('Built',len(rows),'artists')
